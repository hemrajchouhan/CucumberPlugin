package seleniumGrid;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class DifferentBrowsers {

	private WebDriver driver;
	static Properties path = new Properties();
	private static Logger log = Logger.getLogger(DifferentBrowsers.class);

	public WebDriver getBrowser(String browserName, String browserType) throws MalformedURLException {

		try {

			path.load(new FileInputStream("path.properties"));

			if (browserName.equalsIgnoreCase("firefox") && browserType.equalsIgnoreCase("local")) {
				System.out
				.println("---------------: Inside firefox profile :--------------");

				DesiredCapabilities ff = DesiredCapabilities.firefox();
				ff.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
						UnexpectedAlertBehaviour.ACCEPT);
				ff.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
				ff.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				ff.setCapability(CapabilityType.ENABLE_PERSISTENT_HOVERING, true);
				ff.setCapability(CapabilityType.HAS_NATIVE_EVENTS, true);

				driver = new FirefoxDriver(ff);
				System.out
				.println("==========:::: got firefox driver ::::===========");

			} else if (browserName.equalsIgnoreCase("chrome") && browserType.equalsIgnoreCase("local")) {
				System.out
				.println("---------------: Inside chrome profile :--------------");

				DesiredCapabilities chro = DesiredCapabilities.chrome();
				chro.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
						UnexpectedAlertBehaviour.ACCEPT);
				chro.setCapability(CapabilityType.ACCEPT_SSL_CERTS,true);
				chro.setCapability(CapabilityType.HAS_NATIVE_EVENTS,true);
				chro.setCapability(CapabilityType.SUPPORTS_FINDING_BY_CSS,true);
				chro.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT,true);
				chro.setCapability(CapabilityType.SUPPORTS_ALERTS,true);
				chro.setCapability(CapabilityType.ENABLE_PERSISTENT_HOVERING, true);    
				System.setProperty("webdriver.chrome.driver",path.getProperty("chromeDriver2.6"));

				driver = new ChromeDriver(chro);
				System.out
				.println("==========:::: got Chrome driver ::::===========");
			} else if (browserName.equalsIgnoreCase("opera") && browserType.equalsIgnoreCase("local")) {
				System.out
				.println("---------------: Inside opera profile :--------------");
				DesiredCapabilities opera = DesiredCapabilities.chrome();
				opera.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
						UnexpectedAlertBehaviour.IGNORE);
				opera.setCapability("opera.binary","C:\\Program Files\\Opera\\launcher.exe");
				driver = new OperaDriver(opera);
				System.out
				.println("==========:::: got opera driver ::::===========");
			} else if (browserName.equalsIgnoreCase("firefox") && browserType.equalsIgnoreCase("remote")) {
				System.out.println("---------------: Inside remote firefox profile :--------------");

				DesiredCapabilities ff = DesiredCapabilities.firefox();
				ff.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
						UnexpectedAlertBehaviour.ACCEPT);
				ff.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				ff.setCapability(CapabilityType.ENABLE_PERSISTENT_HOVERING, true);
				ff.setCapability(CapabilityType.HAS_NATIVE_EVENTS, true);
				ff.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);

				driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), ff);
				System.out.println("==========:::: got remote firefox driver ::::===========");
			}
			else if (browserName.equalsIgnoreCase("chrome") && browserType.equalsIgnoreCase("remote")) {
				System.out.println("---------------: Inside remote chrome profile :--------------");

				DesiredCapabilities chro = DesiredCapabilities.chrome();
				chro.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
						UnexpectedAlertBehaviour.ACCEPT);
				chro.setCapability(CapabilityType.ACCEPT_SSL_CERTS,true);
				chro.setCapability(CapabilityType.HAS_NATIVE_EVENTS,true);
				chro.setCapability(CapabilityType.SUPPORTS_FINDING_BY_CSS,true);
				chro.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT,true);
				chro.setCapability(CapabilityType.SUPPORTS_ALERTS,true);
				chro.setCapability(CapabilityType.ENABLE_PERSISTENT_HOVERING, true);

				System.setProperty("webdriver.chrome.driver",path.getProperty("chromeDriver2.6"));

				chro.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), chro);

				System.out.println("==========:::: got remote Chrome driver ::::===========");
			} else if (browserName.equalsIgnoreCase("opera") && browserType.equalsIgnoreCase("remote")) {
				System.out
				.println("---------------: Inside remote opera profile :--------------");
				DesiredCapabilities opera = DesiredCapabilities.opera();
				opera.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
						UnexpectedAlertBehaviour.IGNORE);
				opera.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), opera);

				System.out.println("==========:::: got remote opera driver ::::===========");
			} 

			else {

				System.out.println("default firefox driver called");
				driver = new FirefoxDriver();
			}

		} catch (IOException e) {
			log.error("An error occured while instantiating driver.");
			e.printStackTrace();
		}
		return driver;

	}
}