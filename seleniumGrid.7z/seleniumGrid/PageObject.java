package seleniumGrid;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class PageObject extends PageBase {

	public PageObject(WebDriver driver) {
		super.driver = driver; //gets driver from parent class
	}


	WebDriverWait wait = new WebDriverWait(driver, EXPLICIT_TIMEOUT_VALUE);

	@FindBy(id = "abc")
	private WebElement findAbc;

	@FindBy(xpath= "//input[@id='xyz']")
	private WebElement findXyz;

	@FindBy(id = "sample")
	private WebElement findSample;

	public void clickABCButton() {

		findAbc.click();

	}

	public void isXyzLabelPresent() {

		Assert.assertEquals(findXyz.getText(), "");
	}
}