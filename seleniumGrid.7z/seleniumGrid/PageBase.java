package seleniumGrid;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class PageBase {


	protected WebDriver driver;
	protected WebElement element;

	private static Logger log = Logger.getLogger(PageBase.class);
	public static final int IMPLICIT_TIMEOUT_VALUE = 30; // seconds
	public static final int EXPLICIT_TIMEOUT_VALUE = 30; // seconds 
	public static final int PAGELOAD_TIMEOUT_VALUE = 10; // seconds 
	static Properties path = new Properties();

	public void sleeper(int timeInMilliSeconds) {

		try {
			Thread.sleep(timeInMilliSeconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void open(String url) {

		Assert.assertNotNull(this.driver);
		this.driver.get(url);

	}

	public void close() {

		this.driver.quit();
	}

	public String getTitle() {

		return this.driver.getTitle();
	}

	public void implicitTimeout() {

		this.driver.manage().timeouts()
		.implicitlyWait(IMPLICIT_TIMEOUT_VALUE, TimeUnit.SECONDS);
	}

	public void logOut() {

		this.driver.findElement(By.id("forLogout")).click();
	}
}